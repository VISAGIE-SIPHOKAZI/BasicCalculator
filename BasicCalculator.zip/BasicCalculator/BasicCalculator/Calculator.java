import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Calculator extends JFrame implements ActionListener {
    private JTextField display;
    private String currentInput = "";
    private double firstNumber = 0;
    private String operator = "";
    private boolean isNewInput = true;

    public Calculator() {
        setTitle("Calculator");
        setSize(320, 480);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Display area
        display = new JTextField();
        display.setEditable(false);
        display.setFont(new Font("Arial", Font.BOLD, 32));
        display.setHorizontalAlignment(SwingConstants.RIGHT);
        display.setPreferredSize(new Dimension(300, 70));
        display.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        add(display, BorderLayout.NORTH);

        // Panel with GridBagLayout
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.weightx = 1;
        gbc.weighty = 1;

        String[][] buttons = {
                {"7", "8", "9", "/"},
                {"4", "5", "6", "*"},
                {"1", "2", "3", "-"},
                {"0", ".", "C", "+"},
        };

        // Add normal buttons
        for (int row = 0; row < buttons.length; row++) {
            for (int col = 0; col < buttons[row].length; col++) {
                gbc.gridx = col;
                gbc.gridy = row;
                JButton btn = new JButton(buttons[row][col]);
                btn.setFont(new Font("Arial", Font.BOLD, 20));
                btn.addActionListener(this);
                panel.add(btn, gbc);
            }
        }

        // Add "=" button that spans 2 columns at bottom right
        JButton equalBtn = new JButton("=");
        equalBtn.setFont(new Font("Arial", Font.BOLD, 20));
        equalBtn.addActionListener(this);
        gbc.gridx = 2;
        gbc.gridy = 4;
        gbc.gridwidth = 2; // Span two columns
        panel.add(equalBtn, gbc);

        add(panel, BorderLayout.CENTER);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        String command = e.getActionCommand();

        if ("0123456789.".contains(command)) {
            if (isNewInput) {
                currentInput = "";
                isNewInput = false;
            }
            currentInput += command;
            display.setText(currentInput);
        } else if ("+-*/".contains(command)) {
            try {
                firstNumber = Double.parseDouble(currentInput);
            } catch (Exception ex) {
                display.setText("Error");
                return;
            }
            operator = command;
            isNewInput = true;
        } else if (command.equals("=")) {
            try {
                double secondNumber = Double.parseDouble(currentInput);
                double result = 0;

                switch (operator) {
                    case "+": result = firstNumber + secondNumber; break;
                    case "-": result = firstNumber - secondNumber; break;
                    case "*": result = firstNumber * secondNumber; break;
                    case "/":
                        if (secondNumber == 0) {
                            display.setText("Cannot divide by 0");
                            return;
                        }
                        result = firstNumber / secondNumber;
                        break;
                    default:
                        display.setText("?");
                        return;
                }

                if (result % 1 == 0)
                    display.setText(String.valueOf((int) result));
                else
                    display.setText(String.valueOf(result));

                currentInput = String.valueOf(result);
                isNewInput = true;
            } catch (Exception ex) {
                display.setText("Error");
            }
        } else if (command.equals("C")) {
            currentInput = "";
            operator = "";
            firstNumber = 0;
            display.setText("");
            isNewInput = true;
        }
    }

    public static void main(String[] args) {
        new Calculator();
    }
}


